screenX, screenY = guiGetScreenSize()

function reMap(value, low1, high1, low2, high2)
	return low2 + (value - low1) * (high2 - low2) / (high1 - low1)
end

local responsiveMultipler = reMap(screenX, 1024, 1920, 0.75, 1)

function resp(num)
	return num * responsiveMultipler
end

function respc(num)
	return math.ceil(num * responsiveMultipler)
end


myriadpro = dxCreateFont("files/fonts/myriadpro.ttf", respc(18), false, "antialiased")

addEventHandler("onClientResourceStart", resourceRoot, 
	function()
		engineImportTXD(engineLoadTXD("files/taxi.txd", 1313), 1313)
		engineReplaceModel(engineLoadDFF("files/taxi.dff", 1313), 1313)
	end
)

function showTooltip(x, y, text, subText, showItem)
	text = tostring(text)
	subText = subText and tostring(subText)

	if text == subText then
		subText = nil
	end

	local textW = dxGetTextWidth(text, 1, "clear", true) + resp(20)
	
	if subText then
		textW = math.max(textW, dxGetTextWidth(subText, 1, "clear", true) + resp(20))
		text = "#3d7abc" .. text .. "\n#ffffff" .. subText
	end

	local sy = resp(30)

	if subText then
		local _, lines = string.gsub(subText, "\n", "")
		
		sy = sy + resp(12) * (lines + 1)
	end

	local drawnOnTop = true

	if showItem then
		x = math.floor(x - textW / 2)
		drawnOnTop = false
	else
		x = math.max(0, math.min(screenX - textW, x))
		y = math.max(0, math.min(screenY - sy, y))
	end

	dxDrawRectangle(x, y, textW, sy, tocolor(0, 0, 0, 190), drawnOnTop)
	dxDrawText(text, x, y, x + textW, y + sy, tocolor(255, 255, 255), 0.5, myriadpro, "center", "center", false, false, drawnOnTop, true)
end