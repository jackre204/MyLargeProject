availableItems = {
	-- [ItemID] = {Név, Leírás, Súly, Stackelhető, Fegyver ID, Töltény item ID, Eldobható, Model, RotX, RotY, RotZ, Z offset}
	[1] = {"Jármű kulcs", "Jármû kulcs, a gépjárművedhez.", 0.1, false, -1, -1},
	[2] = {"Lakás kulcs", "Lakáskulcs a lakásodhoz", 0.1, false, -1, -1},
	[3] = {"Kapu távirányító", "Távirányító egy kapuhoz", 0.1, false, -1, -1},
	[4] = {"Rádió", "Egy kis walki-talkie rádió.", 0.8, false, -1, -1},
	[5] = {"Telefon", "Egy okos telefon", 0.8, false, -1, -1},
	[6] = {"Boxer", "Kicsit nagyobb pofont lehet vele osztani.", 0.5, false, 1, -1},
	[7] = {"Vipera", "Wardis anyabaszó készlete.", 0.5, false, 2, -1},
	[8] = {"Gumibot", "Gumibot, tartani a rendet.", 0.8, false, 3, -1},
	[9] = {"Kés", "Egy fegyvernek minősülő kés.", 0.8, false, 4, -1},
	[10] = {"Baseball ütő", "Egy szép darab baseball ütő.", 1, false, 5, -1},
	[11] = {"Ásó", "Egy szép darab ásó.", 1.5, false, 6, -1},
	[12] = {"Biliárd dákó", "Egy hosszú biliárd dákó.", 0.8, false, 7, -1},
	[13] = {"Katana", "Ősi japán ereklye.", 3, false, 8, -1},
	[14] = {"Láncfűrész", "Egy benzines motoros láncfűrész.", 2, false, 9, -1},
	[15] = {"Sokkoló", "Sokkoló pisztoly", 0.25, false, 24, -1},
	[16] = {"Glock 17", "Egy Glock 17-es.", 3, false, 22, 42},
	[17] = {"Hangtompítós Colt 45", "Egy Colt45-ös hangtompítóval szerelve.", 3, false, 23, 42},
	[18] = {"Desert Eagle 	 pisztoly", "Nagy kaliberű Desert Eagle pisztoly.", 3, false, 24, 42},
	[19] = {"Sörétes puska", "Nagy kaliberű sörétes puska.", 6, false, 25, 47},
	[20] = {"Rövid csövű sörétes puska", "Nagy kaliberű sörétes puska levágott csővel", 6, false, 26, 47},
	[21] = {"SPAZ-12 taktikai sörétes puska", "SPAZ-12 taktikai sörétes puska elit fegyver.", 6, false, 27, 47},
	[22] = {"Uzi", "Uzi géppisztoly.", 3, false, 28, 45},
	[23] = {"MP5", "MP5-ös fegyver.", 3, false, 29, 45},
	[24] = {"TEC-9", "TEC-9-es gépfegyver.", 3, false, 32, 45},
	[25] = {"AK-47", "AK-47-es gépfegyver.", 5, false, 30, 43},
	[26] = {"M4", "M4-es gépfegyver.", 5, false, 31, 46},
	[27] = {"Vadász puska", "Vadász puska a pontos és határozott lövéshez.", 6, false, 33, 44},
	[28] = {"Remington 700", "Remington 700-as puska.", 6, false, 34, 44},
	[29] = {"Flamethrower", "Flamethrower.", 1.23, false, 37, -1},
	[30] = {"Flashbang", "Flashbang", 0.5, false, 16, -1},
	[31] = {"Füst gránát", "Füst gránát a tökéletes taktikai fegyver.", 0.54, false, 17, -1},
	[32] = {"Molotov koktél", "Molotov koktél.", 1.23, false, 18, -1},
	[33] = {"Spray kanna", "Spray kanna.", 0.3, false, 41, 151},
	[34] = {"Festék patron", "Festék patron fújós spayekhez", 0.001, true, -1, -1},
	[35] = {"Poroltó", "Poroltó", 0.001, false, 42, 98},

	[36] = {"Csákány", "Csákány", 1.23, false, 15, -1},
	[37] = {"Balta", "Balta", 1.23, false, 10, -1},
	[38] = {"Bárd", "Bárd.", 1.23, false, 12, -1},
	[39] = {"Virágok", "Egy csokor virág.", 0.3, false, 14, -1},
	[40] = {"Sétapálca", "Sétapálca.", 0.2, false, 15, -1},
	[41] = {"Ejtőernyő", "Ejtőernyő.", 2.23, false, 46, -1},

	[42] = {"5x9mm-es töltény", "Colt45, Desert 5x9mm-es töltény", 0.001, true, -1, -1},
	[43] = {"AK47-es töltény", "AK47-es töltény", 0.001, true, -1, -1},
	[44] = {"Vadászpuska töltény", "Hosszú Vadászpuska töltény", 0.001, true, -1, -1},
	[45] = {"Kis gépfegyver töltények", "Kis gépfegyver töltények (UZI,MP5)", 0.001, true, -1, -1},
	[46] = {"M4-es gépfegyver töltény", "M4-es gépfegyver töltény", 0.001, true, -1, -1},
	[47] = {"Sörétes töltény", "Sörétes töltény", 0.001, true, -1, -1},

	[48] = {"Bilincs", "Bilincs", 0.8, false, -1, -1},
	[49] = {"Bilincskulcs", "Bilincskulcs", 0.005, false, -1, -1},
	[50] = {"Széf kulcs", "Széf kulcs", 0.25, false, -1, -1},

	[51] = {"Instant Fix Kártya", "Amikor egy isteni erő újjáéleszti az autódat, amiben ülsz.", 0, true, -1, -1},
	[52] = {"Instant Üzemanyag Kártya", "S lőn, teli a tank, ha a kocsiba ülsz.", 0, true, -1, -1},
	[53] = {"Instant Gyógyítás", "S lőn, egy isteni csoda felsegít téged.", 0, false, -1, -1},

	[54] = {"A fegyvermester: Glock 17", "", 1, false, -1, -1},
	[55] = {"A fegyvermester: A hangtompítós Colt-45", "", 1, false, -1, -1},
	[56] = {"A fegyvermester: Desert Eagle", "", 1, false, -1, -1},
	[57] = {"A fegyvermester: UZI & TEC-9", "", 1, false, -1, -1},
	[58] = {"A fegyvermester: P90", "", 1, false, -1, -1},
	[59] = {"A fegyvermester: AK-47", "", 1, false, -1, -1},
	[60] = {"A fegyvermester: M4", "", 1, false, -1, -1},
	[61] = {"A fegyvermester: Vadász-Mesterlövész puska", "", 1, false, -1, -1},
	[62] = {"A fegyvermester: Sörétes puska", "", 1, false, -1, -1},
	[63] = {"A fegyvermester: Taktikai sörétes puska", "", 1, false, -1, -1},

 	[64] = {"Bankkártya", "", 0.1, false, -1, -1},
 	[65] = {"Személyi igazolvány", "", 0.1, false, -1, -1},
 	[66] = {"Horgászengedély", "", 0.1, false, -1, -1},
 	[67] = {"Útlevél", "", 0.1, false, -1, -1},
 	[68] = {"Jogosítvány", "", 0.1, false, -1, -1},
 	[69] = {"Üres adásvételi", "", 0.1, false, -1, -1},
 	[70] = {"Adásvételi", "", 0.1, false, -1, -1},
	[71] = {"Jegyzetfüzet", "", 0.1, false, -1, -1},
	[72] = {"Füzetlap", "", 0.1, false, -1, -1},
	[73] = {"Toll", "", 0.1, false, -1, -1},
	[74] = {"Számla", "", 0.1, false, -1, -1},
	[75] = {"Fegyverengedély", "", 0.1, false, -1, -1},
	[76] = {"A fegyvermester: A lefűrészelt sörétes", "Az alábbi könyv elolvasásával az adott fegyver mesterévé válhatsz", 1, false, -1, -1},
	[77] = {"Sajtospogácsa", "Sajtospogácsa", 0.2, true, -1, -1},
	[78] = {"Krémes", "Krémes", 0.2, true, -1, -1},
	[79] = {"Alma", "Egy szép piros alma.", 0.2, true, -1, -1},
	[80] = {"Narancs", "Egy kis vitamin a szervezetbe!", 0.2, true, -1, -1},
	[81] = {"Sült marhahús", "Steak.", 0.2, true, -1, -1},
	[82] = {"Fajita", "Fajita.", 0.2, true, -1, -1},
	[83] = {"Duplahúsos hamburger", "Hambi :')", 0.2, true, -1, -1},
	[84] = {"Bacon burger", "Hambi :')", 0.2, true, -1, -1},
	[85] = {"Sajtburger", "Hambi :')", 0.2, true, -1, -1},
	[86] = {"Hotdog", "Hotdog :')", 0.2, true, -1, -1},
	[87] = {"Sült csirkehús", "Steak.", 0.2, true, -1, -1},
	[88] = {"Banán", "Gyümölcs.", 0.2, true, -1, -1},
	[89] = {"Eper", "Gyümölcs.", 0.2, true, -1, -1},
	[90] = {"Áfonya", "Gyümölcs.", 0.2, true, -1, -1},
	[91] = {"Mirinda szelet", "Sütemény.", 0.2, true, -1, -1},
	[92] = {"Víz", "Egy hűsítő ital.", 0.2, true, -1, -1},
	[93] = {"Redbull Energy", "Nem egészséges lötty.", 0.2, true, -1, -1},
	[94] = {"Monster Energy", "Nem egészséges lötty.", 0.2, true, -1, -1},
	[95] = {"Hell Energy", "Nem egészséges lötty.", 0.2, true, -1, -1},
	[96] = {"Kávé", "Szar koffeinos lötty.", 0.2, true, -1, -1},
	[97] = {"Cappuccino", "Szar koffeinos lötty.", 0.2, true, -1, -1},

	[98] = {"Antenna", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[99] = {"Ventillátor", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[100] = {"Tranzisztor", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[101] = {"NYÁK", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[102] = {"Mikroprocesszor", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[103] = {"Mini kijelző", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[104] = {"Mikrofon", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[105] = {"Elemlámpa LED", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[106] = {"Kondenzátor", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[107] = {"Hangszóró", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[108] = {"Nyomógomb", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[109] = {"Ellenállás", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[110] = {"Elem", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[111] = {"Műanyag doboz", "Alkatrész az elektronikai gyárban", 0.1, false, -1, -1},
	[112] = {"Walkie Talkie", "Kész termék az elektronikai gyárban", 0.1, false, -1, -1},
	[113] = {"Tápegység", "Kész termék az elektronikai gyárban", 0.1, false, -1, -1},
	[114] = {"Számológép", "Kész termék az elektronikai gyárban", 0.1, false, -1, -1},
	[115] = {"Rádió", "Kész termék az elektronikai gyárban", 0.1, false, -1, -1},
	[116] = {"Elemlámpa", "Kész termék az elektronikai gyárban", 0.1, false, -1, -1},
	[117] = {"Diktafon", "Kész termék az elektronikai gyárban", 0.1, false, -1, -1},
	[118] = {"Flex", "", 0.5, false, -1, -1},
	[119] = {"Pénzkazetta", "", 0.02, false, -1, -1},
	[120] = {"Kalapács", "", 0.3, false, -1, -1},
	[121] = {"Véső", "", 0.2, false, -1, -1},

	[122] = {"Fuvarlevél", "", 0, false, -1, -1},

	[123] = {"Kioperált golyo", "", 0.1, false, -1, -1},
	[124] = {"Tű", "", 0.1, false, -1, -1},
	[125] = {"Csipesz", "", 0.1, false, -1, -1},
	[126] = {"Döglött hal", "", 0.1, false, -1, -1},
	
	[127] = {
		'Számítógép RIG',
		'Crypto bányász gépek rige.',
		5, false, -1, -1
	},
	[128] = {
		'Processzor',
		'Crypto bányész géphez processzor.',
		2, false, -1, -1
	},
	[129] = {
		'Videókártya',
		'Crypto bányász gépbe gpu.',
		2, false, -1, -1
	},
	[130] = {
		'Tápegység',
		'Crypto bányász géphez tápegység.',
		2, false, -1, -1
	},

	[131] = {"Taxilámpa", "", 0.1, false, -1, -1},
	[132] = {"Taxilámpa", "", 0.1, false, -1, -1},

	[133] = {"Villogó", "", 0.1, false, -1, -1},
	[134] = {"Villogó", "", 0.1, false, -1, -1},

	[135] = {"Csekkfüzet", "", 0.2, false, -1, -1},
	[136] = {"Csekk", "", 0.1, false, -1, -1},
}

scratchItems = {}

function resourceStart(res)
	if getResourceName(res) == "sm_lottery" then
		scratchItems = exports.sm_lottery:getScratchItems()
	else
		if source == resourceRoot then
			local sm_lottery = getResourceFromName("sm_lottery")

			if sm_lottery and getResourceState(sm_lottery) == "running" then
				scratchItems = exports.sm_lottery:getScratchItems()
			end
		end
	end
end
addEventHandler("onResourceStart", root, resourceStart)
addEventHandler("onClientResourceStart", root, resourceStart)

function getWeaponNameFromIDNew(id)
	if id == 16 then
		return "Glock-17"
	elseif id == 23 then
		return "MP5"
	elseif id == 28 then
		return "Remington 700"
	elseif id == 27 then
		return "Vadászpuska"
	else
		return getWeaponNameFromID(id)
	end
end

specialItems = {
	--[7] = {"hamburger", 5},
	--[65] = {"cigarette", 20},
}

copyableItems = {
	[65] = true,
	[66] = true,
	[67] = true,
	[68] = true,
	[72] = true,
	[75] = true,
}

ticketGroups = {
	army = {"Szabad rendvédelmi frakció", 21},
	nav = {"Las Venturas Sheriff Department", 13},
	pd = {"Las Venturas Police Department", 1},
	tek = {"Special Weapons And Tactics", 26},
	nni = {"Federal Bureau of Investigation", 12}
}

perishableItems = {
	[136] = 420
}

perishableEvent = {
	[136] = "ticketPerishableEvent"
}

for k, v in pairs(perishableItems) do
	availableItems[k][4] = false
end

weaponSkins = {
	--[265] = 1,
}

function getItemPerishable(itemId)
	if availableItems[itemId] then
		if perishableItems[itemId] then
			return perishableItems[itemId]
		end
	end
	return false
end

function getWeaponSkin(itemId)
	return weaponSkins[itemId]
end

function isKeyItem(itemId)
	if itemId <= 3 or itemId == 154 --[[or itemId == 119]] then
		return true
	end
	return false
end

paperItems = {
	[65] = true,
	[68] = true,
	[66] = true,
	[67] = true,
	[69] = true,
	[71] = true,
	[72] = true,
	[74] = true,
	[75] = true,
	[122] = true,
	[136] = true
}

function isPaperItem(itemId)
	if paperItems[itemId] or scratchItems[itemId] then
		return true
	end
	return false
end

function getItemInfoForShop(itemId)
	return getItemName(itemId), getItemDescription(itemId), getItemWeight(itemId)
end

function getItemNameList()
	local nameList = {}

	for i = 1, #availableItems do
		nameList[i] = getItemName(i)
	end

	return nameList
end

function getItemDescriptionList()
	local descriptionList = {}

	for i = 1, #availableItems do
		descriptionList[i] = getItemDescription(i)
	end

	return descriptionList
end

function getItemName(itemId)
	if availableItems[itemId] then
		return availableItems[itemId][1]
	end
	return false
end

function getItemDescription(itemId)
	if availableItems[itemId] then
		return availableItems[itemId][2]
	end
	return false
end

function getItemWeight(itemId)
	if availableItems[itemId] then
		return availableItems[itemId][3]
	end
	return false
end

function isItemStackable(itemId)
	if availableItems[itemId] then
		return availableItems[itemId][4]
	end
	return false
end

function getItemWeaponID(itemId)
	if availableItems[itemId] then
		return availableItems[itemId][5] or 0
	end
	return false
end

function getItemAmmoID(itemId)
	if availableItems[itemId] then
		return availableItems[itemId][6]
	end
	return false
end

function isItemDroppable(itemId)
	if availableItems[itemId] then
		return availableItems[itemId][7]
	end
	return false
end

function getItemDropDetails(itemId)
	if availableItems[itemId] and availableItems[itemId][8] then
		return availableItems[itemId][8], availableItems[itemId][9], availableItems[itemId][10], availableItems[itemId][11], availableItems[itemId][12]
	end
	return false
end

function isWeaponItem(itemId)
	if availableItems[itemId] and getItemWeaponID(itemId) > 0 then
		return true
	end
	return false
end

function isAmmoItem(itemId)
	if itemId >= 42 and itemId <= 47 or itemId == 34 then
		return true
	end
	return false
end

serialItems = {}

local weaponTypes = {
	[22] = "P",
	[23] = "P",
	[24] = "P",
	[25] = "S",
	[26] = "S",
	[27] = "S",
	[28] = "SM",
	[29] = "SM",
	[32] = "SM",
	[30] = "AR",
	[31] = "AR",
	[33] = "R",
	[34] = "R",
	[12] = "K",
	[8] = "K",
	[4] = "K"
}

for i = 1, #availableItems do
	if isWeaponItem(i) then
		local weaponId = getItemWeaponID(i)

		if weaponId >= 22 and weaponId <= 39 or weaponId == 12 or weaponId == 8 or weaponId == 4 or weaponId == 1 then
			availableItems[i][4] = false

			if i == 15 then
				serialItems[i] = "T"
			else
				serialItems[i] = weaponTypes[weaponId] or "O"
			end
		end
	end
end

local nonStackableItems = {}

for i = 1, #availableItems do
	if not isItemStackable(i) then
		table.insert(nonStackableItems, i)
	end
end

function getNonStackableItems()
	return nonStackableItems
end

craftDoNotTakeItems = {
	--[34] = true,
}

availableRecipes = {
	[1] = {
		name = "Rádió",
		items = {
			[1] = {false, 104, 103},
			[2] = {98, 100, 106},
			[3] = {false, 101, 111}
		},
		finalItem = {115, 1},
		requiredJob = 1,
		suitableColShapes = {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14},
		category = "Elektronika"
	},
	
	[2] = {
		name = "Walkie Talkie",
		items = {
			[1] = {106, 103, 108},
			[2] = {98, 100, 110},
			[3] = {104, 101, 111}
		},
		finalItem = {112, 1},
		requiredJob = 1,
		suitableColShapes = {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14},
		category = "Elektronika"
	},

	[3] = {
		name = "Diktafon",
		items = {
			[1] = {false, 104, false},
			[2] = {110, 101, 103},
			[3] = {109, 107, 111}
		},
		finalItem = {117, 1},
		requiredJob = 1,
		suitableColShapes = {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14},
		category = "Elektronika"
	},

	[4] = {
		name = "Elemlámpa",
		items = {
			[1] = {false, 105, false},
			[2] = {108, 109, 111},
			[3] = {false, 110, false}
		},
		finalItem = {116, 1},
		requiredJob = 1,
		suitableColShapes = {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14},
		category = "Elektronika"
	},

	[5] = {
		name = "Tápegység",
		items = {
			[1] = {false, 106, false},
			[2] = {108, 109, 111},
			[3] = {101, 99, false}
		},
		finalItem = {113, 1},
		requiredJob = 1,
		suitableColShapes = {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14},
		category = "Elektronika"
	},

	[6] = {
		name = "Számológép",
		items = {
			[1] = {false, 103, 108},
			[2] = {100, 102, 110},
			[3] = {false, 101, 111}
		},
		finalItem = {114, 1},
		requiredJob = 1,
		suitableColShapes = {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14},
		category = "Elektronika"
	}
}
